import bpy

from bpy.props import *

# class TLM_CyclesSceneProperties(bpy.types.PropertyGroup):

#     teeeeest : bpy.props.EnumProperty(
#         items = [('CPU', 'CPU', 'Use the processor to bake textures'),
#                     ('GPU', 'GPU', 'Use the graphics card to bake textures')],
#                 name = "Device", 
#                 description="Select whether to use the CPU or the GPU for baking", 
#                 default="CPU")

# bpy.types.Scene.TLM_EngineProperties = bpy.props.PointerProperty(type=cycles.TLM_CyclesSceneProperties)



class SuperBakerUI(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "SuperBakser"
    bl_idname = "OBJECT_PT_superbaker"
    
    #bl_space_type = 'PROPERTIES'
    #bl_region_type = 'WINDOW'
    #bl_context = "object"
    
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"
    bl_label = "SuperBaker 2"

    def draw(self, context):
        layout = self.layout

        obj = context.object

        row = layout.row()
        row.label(text="Hello world 1!", icon='WORLD_DATA')

        row = layout.row()
        row.label(text="Active object is: " + obj.name)
        row = layout.row()
        row.prop(obj, "name")

        # row.prop(engineProperties, "teeeeest")
        # row = layout.row(align=True)

        row = layout.row()
        row.operator("superbaker.bake_single_object")


# register, unregister  = bpy.utils.register_classes_factory([Button_BakeSingle])

def register():
    bpy.utils.register_class(SuperBakerUI)

def unregister():
    bpy.utils.unregister_class(SuperBakerUI)

if __name__ == "__main__":
    register()