import bpy
import time

class SuperBaker_BakeSingleObject(bpy.types.Operator):
    bl_idname = "superbaker.bake_single_object"
    bl_label = "Bake Single Object (SuperBaker) 5"
    bl_description = "Bake Single Object"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        print("Teste")
        time.sleep(15)
        print("Test2")
        return {'RUNNING_MODAL'}


# register, unregister  = bpy.utils.register_classes_factory([SuperBaker_BakeSingleObject])

# if __name__ == "__main__":
#     register()

def register():
    bpy.utils.register_class(SuperBaker_BakeSingleObject)

def unregister():
    bpy.utils.unregister_class(SuperBaker_BakeSingleObject)

if __name__ == "__main__":
    register()