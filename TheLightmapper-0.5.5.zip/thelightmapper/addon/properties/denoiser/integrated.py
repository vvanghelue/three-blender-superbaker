import bpy
from bpy.props import *

class TLM_IntegratedDenoiseEngineProperties(bpy.types.PropertyGroup):